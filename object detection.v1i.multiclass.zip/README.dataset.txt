# object detection  > 2023-01-09 11:42pm
https://universe.roboflow.com/exelk-tt0lg/object-detection-ji5ia

Provided by a Roboflow user
License: CC BY 4.0

